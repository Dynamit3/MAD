package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class login extends AppCompatActivity {
    Button signup,login_btn;
    ImageView image;
    TextView logotext,slogontext;
    TextInputLayout username,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        signup= findViewById(R.id.sign);
        image=findViewById(R.id.img);
        logotext=findViewById(R.id.logo_name);
        slogontext=findViewById(R.id.slogon_name);
        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        login_btn=findViewById(R.id.login);



        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login.this,registration.class);
                Pair[] pairs=new Pair[7];

                pairs[0] = new Pair<View, String>(image,"img");
                pairs[1] = new Pair<View, String>(logotext,"logo_name");
                pairs[2] = new Pair<View, String>(slogontext,"slogon_name");
                pairs[3] = new Pair<View, String>(username,"username");
                pairs[4] = new Pair<View, String>(password,"password");
                pairs[5] = new Pair<View, String>(login_btn,"login");
                pairs[6] = new Pair<View, String>(signup,"sign");

                ActivityOptions options =ActivityOptions.makeSceneTransitionAnimation(login.this,pairs);
                startActivity(intent, options.toBundle());
            }
        });
    }
}